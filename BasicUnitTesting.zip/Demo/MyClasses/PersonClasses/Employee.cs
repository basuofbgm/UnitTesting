﻿namespace MyClasses
{
  public class Employee : Person
  {

  }
}
